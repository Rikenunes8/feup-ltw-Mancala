module.exports.home = 'index.html';
module.exports.port = 9015;
